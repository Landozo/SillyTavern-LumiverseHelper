import React, { useState, useMemo, useEffect, useSyncExternalStore } from 'react';
import {
    usePacks,
    useSelections,
    useLumiverseActions,
    useLumiverseStore,
    saveToExtension,
} from '../../store/LumiverseContext';
import { useAdaptiveImagePosition } from '../../hooks/useAdaptiveImagePosition';
import clsx from 'clsx';

// Get store for direct state access
const store = useLumiverseStore;

// SVG icons matching the old design exactly
const SVG_ICONS = {
    star: `<svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
    check: `<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`,
    clear: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`,
    chevron: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`,
    chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`,
    chevronUp: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>`,
    edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`,
    folder: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`,
    definition: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,
    behavior: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`,
    personality: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 10 10H12V2z"></path><path d="M12 2a10 10 0 0 1 10 10"></path><circle cx="12" cy="12" r="6"></circle></svg>`,
    sort: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="14" y2="6"></line><line x1="4" y1="12" x2="11" y2="12"></line><line x1="4" y1="18" x2="8" y2="18"></line><polyline points="15 15 18 18 21 15"></polyline><line x1="18" y1="9" x2="18" y2="18"></line></svg>`,
    sparkles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>`,
};

/**
 * Render SVG icon from string
 */
function Icon({ name, className }) {
    const svg = SVG_ICONS[name];
    if (!svg) return null;
    return (
        <span
            className={className}
            dangerouslySetInnerHTML={{ __html: svg }}
        />
    );
}

/**
 * Check if an item has multiple content types (for showing "Enable All" button)
 */
function hasMultipleContentTypes(item) {
    const contentTypes = [
        !!item.lumiaDef,
        !!item.lumia_behavior,
        !!item.lumia_personality,
    ].filter(Boolean);
    return contentTypes.length > 1;
}

/**
 * Individual card component matching old design
 */
function LumiaCard({
    item,
    packName,
    isSelected,
    isDominant,
    onSelect,
    onSetDominant,
    onEnableAll,
    showDominant,
    isDefinition,
    animationIndex,
    isEditable,
    onEdit,
}) {
    const [imageLoaded, setImageLoaded] = useState(false);
    const [imageError, setImageError] = useState(false);

    // Get display values - OLD CODE FORMAT
    // item.lumiaDefName is the name field for Lumia items
    // item.lumia_img is the image URL
    const displayName = item.lumiaDefName || 'Unknown';
    const imgToShow = item.lumia_img;

    // Check if this item has multiple content types
    const showEnableAll = hasMultipleContentTypes(item);

    // Adaptive image positioning based on aspect ratio
    const { objectPosition } = useAdaptiveImagePosition(imgToShow);

    const handleCardClick = (e) => {
        // Don't trigger if clicking dominant icon, edit button, or enable-all button
        if (e.target.closest('.lumia-dominant-icon')) return;
        if (e.target.closest('.lumia-edit-icon')) return;
        if (e.target.closest('.lumia-enable-all-icon')) return;
        onSelect(item);
    };

    const handleDominantClick = (e) => {
        e.stopPropagation();
        onSetDominant(item);
    };

    const handleEditClick = (e) => {
        e.stopPropagation();
        if (onEdit) onEdit(item);
    };

    const handleEnableAllClick = (e) => {
        e.stopPropagation();
        if (onEnableAll) onEnableAll(item);
    };

    // Staggered animation delay
    const animationDelay = Math.min(animationIndex * 30, 300);

    return (
        <div
            className={clsx(
                'lumia-card',
                'lumia-card-appear',
                isDefinition && 'definition-card',
                isSelected && 'selected'
            )}
            style={{ animationDelay: `${animationDelay}ms` }}
            onClick={handleCardClick}
            data-pack={packName}
            data-item={displayName}
        >
            <div className="lumia-card-image">
                {imgToShow && !imageError ? (
                    <>
                        <img
                            src={imgToShow}
                            alt={displayName}
                            loading="lazy"
                            className={imageLoaded ? 'lumia-img-loaded' : ''}
                            style={{ objectPosition }}
                            onLoad={() => setImageLoaded(true)}
                            onError={() => setImageError(true)}
                        />
                        {!imageLoaded && <div className="lumia-img-spinner" />}
                    </>
                ) : (
                    <div className="lumia-card-placeholder">?</div>
                )}

                {/* Enable All Icon - shows when item has multiple content types */}
                {showEnableAll && onEnableAll && (
                    <div
                        className="lumia-enable-all-icon"
                        onClick={handleEnableAllClick}
                        title="Enable all traits for this Lumia"
                    >
                        <Icon name="sparkles" />
                    </div>
                )}

                {/* Edit Icon for custom pack items */}
                {isEditable && onEdit && (
                    <div
                        className="lumia-edit-icon"
                        onClick={handleEditClick}
                        title="Edit this Lumia"
                    >
                        <Icon name="edit" />
                    </div>
                )}

                {/* Dominant Star Icon */}
                {showDominant && (
                    <div
                        className={clsx(
                            'lumia-dominant-icon',
                            isDominant && 'dominant'
                        )}
                        onClick={handleDominantClick}
                        title={isDominant ? 'Remove as dominant' : 'Set as dominant trait'}
                    >
                        <Icon name="star" />
                    </div>
                )}

                {/* Selection Checkmark */}
                <div className="lumia-card-check">
                    <Icon name="check" />
                </div>
            </div>

            <div className="lumia-card-info">
                <div className="lumia-card-name">{displayName}</div>
            </div>
        </div>
    );
}

/**
 * Collapsible pack section
 * Can be controlled (via isCollapsed + onToggleCollapse props) or uncontrolled
 */
function PackSection({
    pack,
    items,
    isEditable,
    type,
    isSelected,
    isDominant,
    onSelect,
    onSetDominant,
    onEnableAll,
    showDominant,
    onRemovePack,
    onEditItem,
    // Optional controlled mode props
    isCollapsed: controlledCollapsed,
    onToggleCollapse,
}) {
    const [internalCollapsed, setInternalCollapsed] = useState(false);

    // Use controlled or uncontrolled state
    const isControlled = controlledCollapsed !== undefined;
    const isCollapsed = isControlled ? controlledCollapsed : internalCollapsed;

    const packName = pack.name || pack.packName || 'Unknown Pack';

    const handleHeaderClick = (e) => {
        // Don't collapse if clicking remove button
        if (e.target.closest('.lumia-remove-pack-btn')) return;

        if (isControlled && onToggleCollapse) {
            onToggleCollapse(packName);
        } else {
            setInternalCollapsed(!internalCollapsed);
        }
    };

    return (
        <div className={clsx('lumia-modal-panel', 'lumia-collapsible', 'lumia-pack-section', isCollapsed && 'collapsed')}>
            <div className="lumia-modal-panel-header lumia-collapsible-trigger" onClick={handleHeaderClick}>
                <span className="lumia-panel-collapse-icon">
                    <Icon name="chevron" />
                </span>
                <span className="lumia-modal-panel-icon">
                    <Icon name="folder" />
                </span>
                <span className="lumia-modal-panel-title">{packName}</span>
                {isEditable && <span className="lumia-pack-badge-custom">Custom</span>}
                <span className="lumia-modal-panel-count">{items.length} items</span>
                <button
                    className="lumia-icon-btn-sm lumia-remove-pack-btn"
                    onClick={(e) => {
                        e.stopPropagation();
                        onRemovePack(packName);
                    }}
                    title="Remove Pack"
                >
                    <Icon name="trash" />
                </button>
            </div>
            <div className="lumia-modal-panel-content lumia-modal-panel-content-cards lumia-collapsible-content">
                <div className="lumia-card-grid">
                    {items.map((item, index) => (
                        <LumiaCard
                            key={item.lumiaDefName || item.id || index}
                            item={item}
                            packName={packName}
                            isSelected={isSelected(item, packName)}
                            isDominant={isDominant(item, packName)}
                            onSelect={(item) => onSelect(item, packName)}
                            onSetDominant={(item) => onSetDominant(item, packName)}
                            onEnableAll={onEnableAll ? (item) => onEnableAll(item, packName) : undefined}
                            showDominant={showDominant}
                            isDefinition={type === 'definitions'}
                            animationIndex={index}
                            isEditable={isEditable}
                            onEdit={isEditable ? (item) => onEditItem(item, packName) : undefined}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}

/**
 * Get Lumia items from a pack (filtering out Loom/Narrative Style items)
 *
 * OLD CODE FORMAT:
 * - Lumia items have: lumiaDefName, lumia_img, lumiaDef, lumia_behavior, lumia_personality
 * - Loom items have: loomName, loomCategory, loomContent
 *
 * In the old code, the selection modal shows ALL items with lumiaDefName,
 * regardless of whether they're definitions, behaviors, or personalities.
 * The same items appear in all three selection modals.
 *
 * This matches the old code: packItems.filter((item) => item.lumiaDefName)
 */
function getLumiaItemsFromPack(pack, type) {
    const packItems = pack.items || [];

    // Filter to only Lumia items (have lumiaDefName, not loomCategory)
    return packItems.filter(item => {
        // Skip Loom items
        if (item.loomCategory) return false;
        // Must have lumiaDefName to be a Lumia item
        if (!item.lumiaDefName) return false;
        return true;
    });
}

/**
 * Get header icon based on type
 */
function getHeaderIcon(type) {
    switch (type) {
        case 'definitions': return 'definition';
        case 'behaviors': return 'behavior';
        case 'personalities': return 'personality';
        default: return 'definition';
    }
}

/**
 * Get modal config based on type
 * @param {string} type - The type of selection
 * @param {boolean} chimeraMode - Whether Chimera mode is enabled
 */
function getModalConfig(type, chimeraMode = false) {
    switch (type) {
        case 'definitions':
            // Chimera mode allows multi-select definitions
            if (chimeraMode) {
                return {
                    title: 'Select Chimera Forms',
                    subtitle: 'Choose multiple physical forms to fuse into a Chimera',
                    isMulti: true,
                    dominantKey: null,
                };
            }
            return {
                title: 'Select Definition',
                subtitle: 'Choose the physical form for your Lumia',
                isMulti: false,
                dominantKey: null,
            };
        case 'behaviors':
            return {
                title: 'Select Behaviors',
                subtitle: 'Choose behavioral traits (tap star for dominant)',
                isMulti: true,
                dominantKey: 'dominantBehavior',
            };
        case 'personalities':
            return {
                title: 'Select Personalities',
                subtitle: 'Choose personality traits (tap star for dominant)',
                isMulti: true,
                dominantKey: 'dominantPersonality',
            };
        default:
            return {
                title: 'Select Items',
                subtitle: '',
                isMulti: true,
                dominantKey: null,
            };
    }
}

/**
 * Main selection modal component - card-based design matching old UI
 */
function SelectionModal({
    type,
    multiSelect = true,
    allowDominant = false,
    onClose,
}) {
    const { allPacks } = usePacks();
    const selections = useSelections();
    const actions = useLumiverseActions();

    // Subscribe to Chimera mode for multi-select definitions
    const chimeraMode = useSyncExternalStore(
        store.subscribe,
        () => store.getState().chimeraMode || false,
        () => store.getState().chimeraMode || false
    );
    const selectedDefinitions = useSyncExternalStore(
        store.subscribe,
        () => store.getState().selectedDefinitions || [],
        () => store.getState().selectedDefinitions || []
    );

    const config = getModalConfig(type, chimeraMode);
    const headerIcon = getHeaderIcon(type);

    /**
     * Get the appropriate selection data based on type
     *
     * OLD CODE FORMAT:
     * - Selections are stored as: { packName: string, itemName: string }
     * - selectedItems is an array of { packName, itemName }
     * - dominantItem is { packName, itemName } or null
     */
    const selectionData = useMemo(() => {
        switch (type) {
            case 'behaviors':
                return {
                    selectedItems: selections.behaviors || [],
                    dominantItem: selections.dominantBehavior,
                    toggleAction: actions.toggleBehavior,
                    setDominantAction: actions.setDominantBehavior,
                    clearAction: () => {
                        actions.setSelectedBehaviors([]);
                        actions.setDominantBehavior(null);
                    },
                };
            case 'personalities':
                return {
                    selectedItems: selections.personalities || [],
                    dominantItem: selections.dominantPersonality,
                    toggleAction: actions.togglePersonality,
                    setDominantAction: actions.setDominantPersonality,
                    clearAction: () => {
                        actions.setSelectedPersonalities([]);
                        actions.setDominantPersonality(null);
                    },
                };
            case 'definitions':
                // Chimera mode uses multi-select definitions
                if (chimeraMode) {
                    return {
                        selectedItems: selectedDefinitions,
                        dominantItem: null,
                        toggleAction: actions.toggleChimeraDefinition,
                        setDominantAction: null,
                        clearAction: actions.clearChimeraDefinitions,
                    };
                }
                // Normal single-select definitions
                return {
                    selectedItems: selections.definition ? [selections.definition] : [],
                    dominantItem: null,
                    toggleAction: (selection) => {
                        // selection = { packName, itemName }
                        const current = selections.definition;
                        if (current &&
                            current.packName === selection.packName &&
                            current.itemName === selection.itemName) {
                            actions.setSelectedDefinition(null);
                        } else {
                            actions.setSelectedDefinition(selection);
                        }
                    },
                    setDominantAction: null,
                    clearAction: () => actions.setSelectedDefinition(null),
                };
            default:
                return {
                    selectedItems: [],
                    dominantItem: null,
                    toggleAction: () => {},
                    setDominantAction: null,
                    clearAction: () => {},
                };
        }
    }, [type, selections, actions, chimeraMode, selectedDefinitions]);

    const {
        selectedItems,
        dominantItem,
        toggleAction,
        setDominantAction,
        clearAction,
    } = selectionData;

    // Save to extension whenever selections change
    // This ensures the settingsManager (which macros read from) stays in sync
    useEffect(() => {
        // Debounce slightly to avoid rapid saves during multi-click
        const timeoutId = setTimeout(() => {
            saveToExtension();
        }, 100);
        return () => clearTimeout(timeoutId);
    }, [selectedItems, dominantItem]);

    // State for collapse/expand all
    const [collapsedPacks, setCollapsedPacks] = useState(new Set());

    // State for sorting
    const [sortBy, setSortBy] = useState('default'); // 'default', 'name', 'author'

    // Filter packs to get Lumia items of the correct type
    const packsWithItems = useMemo(() => {
        return allPacks
            .map((pack) => {
                const lumiaItems = getLumiaItemsFromPack(pack, type);
                return {
                    ...pack,
                    lumiaItems,
                    isEditable: pack.isCustom || pack.isEditable || false,
                };
            })
            .filter((pack) => pack.lumiaItems.length > 0);
    }, [allPacks, type]);

    // Sorted packs
    const sortedPacks = useMemo(() => {
        if (sortBy === 'default') return packsWithItems;

        return [...packsWithItems].sort((a, b) => {
            if (sortBy === 'name') {
                const nameA = (a.name || a.packName || '').toLowerCase();
                const nameB = (b.name || b.packName || '').toLowerCase();
                return nameA.localeCompare(nameB);
            }
            if (sortBy === 'author') {
                const authorA = (a.author || '').toLowerCase();
                const authorB = (b.author || '').toLowerCase();
                return authorA.localeCompare(authorB);
            }
            return 0;
        });
    }, [packsWithItems, sortBy]);

    // Collapse/Expand all functions
    const collapseAll = () => {
        const allPackNames = packsWithItems.map(p => p.name || p.packName);
        setCollapsedPacks(new Set(allPackNames));
    };

    const expandAll = () => {
        setCollapsedPacks(new Set());
    };

    const togglePackCollapse = (packName) => {
        setCollapsedPacks(prev => {
            const next = new Set(prev);
            if (next.has(packName)) {
                next.delete(packName);
            } else {
                next.add(packName);
            }
            return next;
        });
    };

    const isPackCollapsed = (packName) => collapsedPacks.has(packName);

    /**
     * Check if an item is selected
     * Comparisons use packName + itemName (old code format)
     *
     * @param {Object} item - The item from pack.items
     * @param {string} packName - The pack this item belongs to
     */
    const isSelected = (item, packName) => {
        const itemName = item.lumiaDefName;
        return selectedItems.some((selected) =>
            selected.packName === packName && selected.itemName === itemName
        );
    };

    /**
     * Check if an item is the dominant trait
     */
    const isDominant = (item, packName) => {
        if (!dominantItem) return false;
        const itemName = item.lumiaDefName;
        return dominantItem.packName === packName && dominantItem.itemName === itemName;
    };

    /**
     * Handle item selection
     * Converts item + packName to { packName, itemName } format for storage
     */
    const handleSelect = (item, packName) => {
        const selection = {
            packName: packName,
            itemName: item.lumiaDefName,
        };
        toggleAction(selection);
    };

    /**
     * Handle setting dominant trait
     */
    const handleSetDominant = (item, packName) => {
        if (!setDominantAction) return;

        const selection = {
            packName: packName,
            itemName: item.lumiaDefName,
        };

        // If item isn't selected, select it first
        if (!isSelected(item, packName)) {
            toggleAction(selection);
        }

        // Toggle dominant - use selection format { packName, itemName }
        if (isDominant(item, packName)) {
            setDominantAction(null);
        } else {
            setDominantAction(selection);
        }
    };

    const handleClearAll = () => {
        clearAction();
    };

    const handleRemovePack = (packName) => {
        if (!window.confirm(`Delete pack "${packName}"? This action cannot be undone.`)) {
            return;
        }
        actions.removeCustomPack(packName);
        saveToExtension();
    };

    /**
     * Handle editing a Lumia item from a custom pack
     * Opens the LumiaEditorModal with the item for editing
     */
    const handleEditItem = (item, packName) => {
        actions.openModal('lumiaEditor', {
            packName: packName,
            editingItem: item,
        });
    };

    /**
     * Handle enabling all traits for a Lumia item
     * Uses the enableAllTraitsForLumia action from the store
     */
    const handleEnableAll = (item, packName) => {
        const itemName = item.lumiaDefName;
        if (itemName) {
            actions.enableAllTraitsForLumia(packName, itemName);
            saveToExtension();
        }
    };

    return (
        <div className="lumia-modal-selection-content">
            {/* Header with icon, title, subtitle, and clear button */}
            <div className="lumia-modal-header-inner">
                <div className="lumia-modal-header-icon">
                    <Icon name={headerIcon} />
                </div>
                <div className="lumia-modal-header-text">
                    <h3 className="lumia-modal-title">{config.title}</h3>
                    <p className="lumia-modal-subtitle">{config.subtitle}</p>
                </div>
                <button className="lumia-clear-btn" onClick={handleClearAll} title="Clear all selections">
                    <Icon name="clear" />
                    <span>Clear</span>
                </button>
            </div>

            {/* Controls - Collapse/Expand and Sort */}
            {sortedPacks.length > 0 && (
                <div className="lumia-modal-controls">
                    {/* Collapse/Expand controls */}
                    <div className="lumia-modal-controls-group">
                        <button
                            className="lumia-modal-control-btn"
                            onClick={expandAll}
                            title="Expand all packs"
                            type="button"
                        >
                            <Icon name="chevronDown" className="lumia-control-icon" />
                            <span>Expand All</span>
                        </button>
                        <button
                            className="lumia-modal-control-btn"
                            onClick={collapseAll}
                            title="Collapse all packs"
                            type="button"
                        >
                            <Icon name="chevronUp" className="lumia-control-icon" />
                            <span>Collapse All</span>
                        </button>
                    </div>

                    {/* Sort dropdown */}
                    <div className="lumia-modal-sort">
                        <Icon name="sort" className="lumia-sort-icon" />
                        <span className="lumia-modal-sort-label">Sort:</span>
                        <select
                            className="lumia-select"
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                        >
                            <option value="default">Default</option>
                            <option value="name">Pack Name</option>
                            <option value="author">Author</option>
                        </select>
                    </div>
                </div>
            )}

            {/* Content - pack sections with cards */}
            <div className="lumia-modal-content">
                {sortedPacks.length === 0 ? (
                    <div className="lumia-modal-empty">
                        No Lumia Packs loaded. Add one in settings!
                    </div>
                ) : (
                    sortedPacks.map((pack) => {
                        const packName = pack.name || pack.packName;
                        return (
                            <PackSection
                                key={pack.id || packName}
                                pack={pack}
                                items={pack.lumiaItems}
                                isEditable={pack.isEditable}
                                type={type}
                                isSelected={isSelected}
                                isDominant={isDominant}
                                onSelect={handleSelect}
                                onSetDominant={handleSetDominant}
                                onEnableAll={handleEnableAll}
                                showDominant={allowDominant && config.isMulti}
                                onRemovePack={handleRemovePack}
                                onEditItem={handleEditItem}
                                isCollapsed={isPackCollapsed(packName)}
                                onToggleCollapse={togglePackCollapse}
                            />
                        );
                    })
                )}
            </div>

            {/* Footer */}
            <div className="lumia-modal-footer">
                <button className="lumia-modal-btn lumia-modal-btn-secondary lumia-modal-close-btn" onClick={onClose}>
                    Close
                </button>
                {config.isMulti && (
                    <button className="lumia-modal-btn lumia-modal-btn-primary lumia-modal-done" onClick={onClose}>
                        Done
                    </button>
                )}
            </div>
        </div>
    );
}

export default SelectionModal;
